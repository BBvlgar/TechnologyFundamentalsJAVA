package company.ArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SumAdjacentEqualNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = (scanner.nextLine());


        String[] numbers = input.split( " ");

        List<Double> doubleList = new ArrayList<>();

        for (String number :
                numbers) {
            doubleList.add(Double.parseDouble(number));
        }








    }
}
