package company.ArrayList;
import java.util.*;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Collectors;

public class AnonymousThreat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> elements = Arrays.stream(scanner.nextLine().split(" "))
                .collect(Collectors.toList());


        String input = "";


        while (!"3:1".equals(input = scanner.nextLine())){

            String[] data = input.split( "\\s+");

            String command = data[0];
            switch (command){
                case "merge":

                    int startIndex = Integer.parseInt(data[1]);
                    int endIndex = Integer.parseInt(data[2]);



                    break;
                case "divide":
                    break;
                case "":
                    break;

            }

        }


    }


    static int validateIndex(int index,int length){

        if (index < 0){
            index = 0;
        }
        if (index > length - 1){
            index = length - 1;
        }
        return 1 ;
    }
}
