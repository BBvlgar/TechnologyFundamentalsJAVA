package company.ArrayList.ArrayListLab;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MergingLists {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> num1 = Arrays.stream(scanner.nextLine().split("\\s+"))
                .collect(Collectors.toList());

        List<String> num2 = Arrays.stream(scanner.nextLine().split("\\s+"))
                .collect(Collectors.toList());

        List<String> sum = new ArrayList<>();

        int max = num1.size() > num2.size() ? num1.size() : num2.size();
        int min = num2.size() > num1.size()  ? num1.size() : num2.size();

        List<String> bigger = new ArrayList<>();
        if (num1.size() > num2.size()){
            bigger =num1;
        } else {
            bigger = num2;
        }

        for (int i = 0; i < min; i++) {

            sum.add(num1.get(i));
            sum.add(num2.get(i));


        }

        for (int i = min; i < max ; i++) {
            sum.add(bigger.get(i));
        }

        System.out.println(sum.toString().replaceAll("[\\[\\],]", ""));



    }
}
