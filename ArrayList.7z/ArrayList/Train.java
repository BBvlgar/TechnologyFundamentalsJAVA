package company.ArrayList;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;


public class Train {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] inputData = scanner.nextLine().split( " ");

        List<Integer> train = new ArrayList<>();

        int maxCapacity = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i <inputData.length ; i++) {
            train.add(Integer.parseInt(inputData[i]));
        }
        String input = "";

        while (!"end".equals(input = scanner.nextLine())){

            String[] trainAdd = input.split( " ");

            if (trainAdd[0].equals("Add")){

                train.add(Integer.parseInt(trainAdd[1]));
            } else {

                for (int i = 0; i < train.size(); i++) {
                    int sum =Integer.parseInt(input);
                    if (sum + train.get(i) <= maxCapacity){
                        train.set(i,sum + train.get(i));
                        break;
                    }

                }
            }

        }

        System.out.println(train
                .toString()
                .replaceAll("[\\[\\],]",""));

    }
}
