package company.ArrayList;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.stream.Collectors;

public class HouseParty {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());


        List<String> list = new ArrayList<>();

        for (int i = 0; i < n; i++) {

            String[] person = scanner.nextLine().split(" ");

            if (person[2].equals("not")){

                if (list.contains(person[0])){
                    list.remove((Object)person[0]);
                } else {
                    System.out.println(person[0] + " is not in the list!");
                }

            } else {
                if (list.contains(person[0])) {
                    System.out.println(person[0] + " is already in the list!");
                } else {
                    list.add(person[0]);
                }
            }


        }

        for (int i = 0; i <list.size() ; i++) {

            System.out.println(list.get(i));
        }

    }
}
