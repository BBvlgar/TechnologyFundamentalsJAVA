package company.ArrayList;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.stream.Collectors;

public class ChangeList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] inputData = scanner.nextLine().split( " ");

        List<String> listNum = new ArrayList<>();

        for (int i = 0; i < inputData.length; i++) {

            listNum.add(inputData[i]);

        }
        String input ="";
        while (!"end".equals(input = scanner.nextLine())){

            String[] command = input.split( "\\s+");

            if (command[0].equals("Delete")){

                listNum =listNum.stream()
                .filter(e -> !e.equals(command[1]))
                .collect(Collectors.toList());
            } else if (command[0].equals("Insert")){

                int position = Integer.parseInt(command[2]);

                if (position >= 0 && position < listNum.size())
                listNum.add(position, command[1]);
            }
        }
        System.out.println(listNum.toString().replaceAll("[\\[,\\]]",""));
    }

}
